package com.tpximpact.trainingtool.user;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmailIgnoreCase(String email);

    boolean existsByEmailIgnoreCase(String email);

    List<User> findTop50ByOrderByXpDesc();

    List<User> findByDisplayNameContainingIgnoreCaseOrderByDisplayName(String q);
}
